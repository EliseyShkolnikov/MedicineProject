import sublime
import sublime_plugin
from ctypes import *

# OPTIONS = '-A2txnxcxlxkxVxGCLxWwYMpxgHUk3W3xjxfxhOxyxC80xLy'
OPTIONS = (
    '--style=attach '
    '--indent=spaces=4 '
    '--attach-closing-while '
    '--indent-labels '
    '--indent-preproc-block '
    '--indent-preproc-cond '
    '--indent-col1-comments '
    '--pad-oper '
    '--pad-comma '
    '--pad-header '
    '--unpad-paren '
    '--delete-empty-lines '
    '--align-pointer=type '
    '--align-reference=type '
    '--break-closing-braces '
    '--attach-return-type '
    '--attach-return-type-decl '
    '--remove-comment-prefix '
    '--max-code-length=69'
)


def error_handler(num, err):
    # AStyle Error Handler Callback
    print('Error in input {}: {}'.format(num, err.decode()))


def memory_allocation(size):
    # AStyle Memory Allocation Callback
    global ALLOCATED
    arr_type = c_char * size    # create a c_char array
    ALLOCATED = arr_type()      # create an array object
    return addressof(ALLOCATED)


class AstyleCommand(sublime_plugin.TextCommand):
    def run(self, edit):
        region = sublime.Region(0, self.view.size())
        formatted_code = astyle_main(
            self.view.substr(region).encode(),
            options_in, ERROR_HANDLER, MEMORY_ALLOCATION)
        if formatted_code is not None:
            formatted_text = formatted_code.decode()
            self.view.replace(edit, region, formatted_text)
            sublime.status_message('AStyle formatted')
            del formatted_code


options_in = OPTIONS.encode()
libc = windll.LoadLibrary(__file__[:-3] + '31.dll')
astyle_main = libc.AStyleMain
astyle_main.restype = c_char_p
ALLOCATED = c_char_p
ERROR_HANDLER = WINFUNCTYPE(None, c_int, c_char_p)(error_handler)
MEMORY_ALLOCATION = WINFUNCTYPE(c_char_p, c_ulong)(memory_allocation)
